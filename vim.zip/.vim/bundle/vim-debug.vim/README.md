vim-debug.vim
=============

This is not a project, just a workaround to be able to install jabapyth/vim-debug with vundle. All credit for the debugger goes to jabapyth.

[vim-debug](https://github.com/jabapyth/vim-debug) is a great python debugger for vim, but to install it you must run a command (install-vim-debug.py) that just creates the needed vim plugin file under your .vim/plugin folder. That way, vim-debug can't be installed using vundle.

This repo just contains the needed vim files as they would be created by the install-vim-debug.py script. Install vim-debug dependencies and use this repo with vundle :)
